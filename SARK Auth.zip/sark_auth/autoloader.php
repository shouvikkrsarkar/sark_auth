<?php

require_once __DIR__ . '\basic\authenticate.php';
require_once __DIR__ . '\basic\user_specific_authenticate.php';

?>