<?php

namespace SarkAuth\Basic;

class Autheticate
{
	protected $default_access_key = '##';
	protected $default_secret = '##';
	
	protected $first_level_secret = '##';
	protected $second_level_secret = '##';
	protected $third_level_secret = '##';
	
	private function encode_secret($secret)
	{	
		$cipher = '##';
		$encryption_key = openssl_digest($cipher, 'md5', true);
		
		$encryption_method = 'AES-128-ECB';
		
		$options = 0;
		
		$encrypted_secret = openssl_encrypt($secret, $encryption_method, $encryption_key, $options); 
		$encoded_secret = base64_encode($encrypted_secret);

		return $encoded_secret;
	}
	
	private function encode_access_key()
	{
		$default_access_key = $this -> default_access_key;
		
		$encoded_access_key = base64_encode($default_access_key);
		
		return $encoded_access_key;
	}
	
	private function decode_secret($secret)
	{
		$encrypted_secret = base64_decode($secret);
		
		$cipher = '##';
		$encryption_key = openssl_digest($cipher, 'md5', true);
		
		$encryption_method = 'AES-128-ECB';
		
		$options = 0;
		
		$secret_to_verify = openssl_decrypt($encrypted_secret, $encryption_method, $encryption_key, $options);
		
		return $secret_to_verify;
	}
	
	private function decode_access_key($access_key)
	{	
		$access_key_to_verify = base64_decode($access_key);
		
		return $access_key_to_verify;
	}
	
	public function verify_credentials($access_key, $secret)
	{
		$default_access_key = $this -> default_access_key;
		$default_secret = $this -> default_secret;
		
		$access_key_to_verify = $this -> decode_access_key($access_key);
		$secret_to_verify = $this -> decode_secret($secret);
		
		$authorize = false;
		
		if (($access_key_to_verify == $default_access_key) and ($secret_to_verify == $default_secret))
		{
			$authorize = true;
		}
		
		return $authorize;
	}
	
	public function authorize($first_secret, $second_secret, $third_secret)
	{
		$first_level_secret = $this -> first_level_secret;
		$second_level_secret = $this -> second_level_secret;
		$third_level_secret = $this -> third_level_secret;
		
		$first_level_secret_to_verify = $this -> decode_secret($first_secret);
		$second_level_secret_to_verify = $this -> decode_secret($second_secret);
		$third_level_secret_to_verify = $this -> decode_secret($third_secret);
		
		$authorize = false;
		
		if (($first_level_secret_to_verify == $first_level_secret) and ($second_level_secret_to_verify == $second_level_secret)  and ($third_level_secret_to_verify == $third_level_secret))
		{
			$authorize = true;
		}
		
		return $authorize;
	}
	
	public function get_access_key()
	{
		$access_key = $this -> encode_access_key();
		
		return $access_key;
	}
	
	public function get_secret()
	{
		$secret = array();
		
		$secret['default_secret'] = $this -> encode_secret($this -> default_secret);
		
		$secret['first_level_secret'] = $this -> encode_secret($this -> first_level_secret);
		$secret['second_level_secret'] = $this -> encode_secret($this -> second_level_secret);
		$secret['third_level_secret'] = $this -> encode_secret($this -> third_level_secret);
		
		return $secret;
	}
	
	public function stop_exec()
	{
		echo '<b>HTTP/1.0 401 Unauthorized</b>'.PHP_EOL;
		echo 'Hey, You do not have proper permissions to access this resource.';
		exit;
	}
}

?>