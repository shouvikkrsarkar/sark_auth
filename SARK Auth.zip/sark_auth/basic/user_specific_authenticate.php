<?php

namespace SarkAuth\Basic;

class User_specific_autheticate
{
	private function verify_user($conn, $user_id)
	{
		$active = 1;
		$data = false;
		
		$sql = 'select * from api_authorization where user_id = '.$user_id.' and active = '.$active;
		$result = mysqli_query($conn, $sql);
		
		if (sizeof($result) == 1)
		{
			$data = true;
		}
		
		return $data;
	}
	
	private function get_user_secret($conn, $user_id)
	{
		$active = 1;
		$user_secret = '';
		
		$sql = 'select secret from api_authorization where user_id = '.$user_id.' and active = '.$active;
		$data = mysqli_query($conn, $sql);
		
		if (sizeof($data) > 0)
		{
			$user_secret = $data[0]['secret'];
		}
		
		return $user_secret;
	}
	
	public function generate_user_secret($conn, $user_id)
	{
		$data = false;
		
		$user_secret = rand(100000000, 9999999999);
		
		$created_at = date('Y-m-d H:i:s');
		$updated_at = date('Y-m-d H:i:s');
		$active = 1;
		
		$sql = 'insert into api_authorization(user_id, secret, created_at, updated_at, active) values('.$user_id.', "'.$user_secret.'", "'.$created_at.'", "'.$updated_at.'", '.$active.')';
		$result = mysqli_query($conn, $sql);
		
		if ($result){ $data = true; }
		
		return $data;
	}
	
	public function update_user_secret($conn, $user_id)
	{
		$data = false;
		
		$user_secret = rand(100000000, 9999999999);
		
		$updated_at = date('Y-m-d H:i:s');
		$active = 1;
		
		$sql = 'update api_authorization set secret = "'.$user_secret.'", updated_at = "'.$updated_at.'", active = '.$active.' where user_id = '.$user_id;
		$result = mysqli_query($conn, $sql);
		
		if ($result){ $data = true; }
		
		return $data;
	}
	
	public function deactivate_user_secret($conn, $user_id)
	{	
		$data = false;
		
		$updated_at = date('Y-m-d H:i:s');
		$active = 0;
		
		$sql = 'update api_authorization set updated_at = "'.$updated_at.'", active = '.$active.' where user_id = '.$user_id;
		$result = mysqli_query($conn, $sql);
		
		if ($result){ $data = true; }
		
		return $data;
	}
	
	private function encode_secret($secret)
	{	
		$cipher = '##';
		$encryption_key = openssl_digest($cipher, 'md5', true);
		
		$encryption_method = 'AES-128-ECB';
		
		$options = 0;
		
		$encrypted_secret = openssl_encrypt($secret, $encryption_method, $encryption_key, $options);
		$encoded_secret = base64_encode($encrypted_secret);
		
		return $encoded_secret;
	}
	
	private function encode_access_key($user_id)
	{	
		$encoded_access_key = base64_encode($user_id);
		
		return $encoded_access_key;
	}
	
	private function decode_secret($secret)
	{
		$encrypted_secret = base64_decode($secret);
		
		$cipher = '##';
		$encryption_key = openssl_digest($cipher, 'md5', true);
		
		$encryption_method = 'AES-128-ECB';
		
		$options = 0;
		
		$secret_to_verify = openssl_decrypt($encrypted_secret, $encryption_method, $encryption_key, $options, $encryption_iv);
		
		return $secret_to_verify;
	}
	
	private function decode_access_key($access_key)
	{	
		$access_key_to_verify = base64_decode($access_key);
		
		return $access_key_to_verify;
	}
	
	public function verify_credentials($conn, $access_key, $secret)
	{	
		$user_id = $this -> decode_access_key($access_key);
		$secret_to_verify = $this -> decode_secret($secret);
		
		$authorize = false;
		
		if ($this -> verify_user($conn, $user_id))
		{
			$user_secret = $this -> get_user_secret($conn, $user_id);
			
			if ($secret_to_verify == $user_secret)
			{
				$authorize = true;
			}
		}
		
		return $authorize;
	}
	
	public function get_access_key($user_id)
	{
		$access_key = $this -> encode_access_key($user_id);
		
		return $access_key;
	}
	
	public function get_secret($conn, $user_id)
	{
		$user_secret = $this -> get_user_secret($conn, $user_id);
		$secret = $this -> encode_secret($user_secret);
		
		return $secret;
	}
}